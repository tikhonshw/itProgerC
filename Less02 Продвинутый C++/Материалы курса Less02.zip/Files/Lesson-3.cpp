﻿#include <iostream>
#include <clocale>
#include <string>

void info(std::string word = "Hello");
int summa(int b, int a = 7);
void count();

int main() {
	setlocale(LC_ALL, "Russian");

	info();
	std::string word = "World";
	info(word);
	std::string home = "Home";
	info(home);

	int x = 71;
	int result = summa(x);
	info(std::to_string(result));

	int res = std::min(6, 8);

	count();
	count();
	count();
	
	return 0;
}

void info(std::string word) {
	int x = 0;
	if (5 == 5) {
		x++;
	}
	x++;
	std::cout << word << "!" << std::endl;
}

int summa(int b, int a) {
	int res = a + b;
	info(std::to_string(res));

	return res;
}

void count() {
	static int x = 0;
	x++;
	std::cout << x << std::endl;
}
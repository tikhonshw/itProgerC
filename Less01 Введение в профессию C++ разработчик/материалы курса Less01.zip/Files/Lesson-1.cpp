﻿#include <iostream>
#include <cstdlib>
#include <clocale>

int main() {
	// Some!!!
	/*
	Some
	some
	some
	*/

	setlocale(LC_ALL, "Russian");
	std::cout << "Hello World!\n\n\n" << "Привет" << 5 << 5.5 << std::endl;
	std::cout << "\t\" \\";
	
	system("pause");
	return 0;
}
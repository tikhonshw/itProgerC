﻿#include <iostream>
#include <clocale>
#include <string>

namespace my_first {
	int some = 9;
	int x = 10;
}

namespace my_second {
	int some = 11;
}

// using namespace my_first;
using my_first::some;
//using namespace std;
using std::string;

int main() {
	setlocale(LC_ALL, "Russian");

	std::cout << some << my_first::x << std::endl;
	std::cout << my_second::some << std::endl;
	string word = "";
	
	
	return 0;
}

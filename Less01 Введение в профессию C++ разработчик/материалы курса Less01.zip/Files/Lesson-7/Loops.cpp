#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");

	// break, continue
	for (int i = 1; i < 20; i++) {
		if (i == 8) break;

		if (i % 2 == 0) continue;

		std::cout << i << std::endl;
	}


	// ����������� �����
	/*for (int i = 1; i <= 150; i *= 25)
		std::cout << i << std::endl;*/

		/*int i = 100;
		while (i >= 10) {
			std::cout << i << std::endl;
			i -= 10;
		}*/

		/*bool isInLoop = true;
		while (isInLoop) {
			std::cout << "Enter action: ";
			char action;
			std::cin >> action;
			if (action == 'q')
				isInLoop = false;
		}*/

		/*int i = 0;
		do {
			std::cout << i << std::endl;
			i++;
		} while (i < 10);*/

	return 0;
}
﻿#include <iostream>
#include <clocale>
#include <string>

#define SOME 100
#define NEWLINE "\n"
#define info {

int main(int argc, char* argv[]) {
	setlocale(LC_ALL, "Russian");
	
	for (int i = 0; i < argc; i++)
		std::cout << argv[i] << std::endl;

	std::cout << SOME << NEWLINE << SOME;

	if (5 == 5) info
	}
	
	return 0;
}

﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	const std::string login = "login", password = "12345";

	std::string user_login, user_pass;
	std::cout << "Enter login: ";
	std::getline(std::cin, user_login);

	std::cout << "Enter password: ";
	std::getline(std::cin, user_pass);

	if (user_login == login && user_pass == password) {
		std::cout << "Вы успешно авторизовались" << std::endl;
		std::cout << "Enter symbol: ";
		char action;
		std::cin >> action;
		if (action == 'D')
			std::cout << "Вы удалили пользователя";
		else if(action == 'E')
			std::cout << "Вы изменили пользователя";
		else
			std::cout << "Вы ввели что-то непонятное";
	} else
		std::cout << "Вы не успешно авторизовались" << std::endl;
	
	return 0;
}
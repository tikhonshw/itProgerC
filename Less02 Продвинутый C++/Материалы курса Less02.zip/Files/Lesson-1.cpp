﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");

	int num = 6;
	int& ref = num;
	ref = 10;
	//std::cout << ref << "\t" << num;

	int num2 = 10;
	int* p, *p2;
	p = &num2;
	//std::cout << p << "\t" << *p;

	p2 = &num;
	// std::cout << &ref << "\t" << &num << "\t" << &p2;

	*p2++;
	// p2++;
	
	int* p3 = new int(11);
	*p3 = 10;
	//std::cout << *p3 << std::endl;
	delete p3;
	p3 = nullptr;
	if(p3 != nullptr)
		std::cout << "P3: " << *p3;

	int a[] = { 3, 6, 7, 2, 6 };
	int* ptr = a;
	for (int i = 0; i < 5; i++)
		std::cout << *(ptr + i) << "\t" << &ptr[i] << std::endl;

	return 0;
}
﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");

	std::string word = "", word2 = "World", word3;
	word[0] = 't';
	char words[255] = "hello world!", words2[4] = "!!!";

	word3 = word + word2;
	strcat_s(words, words2);

	std::cout << strlen(words) << std::endl;

	if(!word.empty())
		std::cout << size(word) << std::endl;

	// if(word >= "")


	// ASCII

	char sym = (char)103;
	int code = int('g');
	for (short i = 0; i < 255; i++)
		std::cout << (char)i << std::endl;
	
	return 0;
}
﻿#include <iostream>
#include <clocale>
#include <string>
#include <cmath>

int main() {
	setlocale(LC_ALL, "Russian");
	
	float x, y, z;
	std::cin >> x >> y >> z;

	float res = x + y + z;
	std::cout << "Result: " << res << std::endl;

	res = x - y - z;
	std::cout << "Result: " << res << std::endl;

	res = x * y * z;
	std::cout << "Result: " << res << std::endl;

	res = x / y / z;
	std::cout << "Result: " << res << std::endl;

	res = int(x) % int(y);
	std::cout << "Result: " << res << std::endl;

	x += 5;
	x++;
	x--;

	std::cout << std::min(5, 7) << std::endl;
	std::cout << std::max(5, 7) << std::endl;
	std::cout << std::sqrt(64) << std::endl;
	std::cout << std::round(5.56) << std::endl;
	std::cout << std::ceil(5.01) << std::endl;
	std::cout << std::floor(5.99) << std::endl;
	
	return 0;
}
//#include <iostream>
//#include <clocale>
//#include <string>
//#include <fstream>
//
//int main() {
//	setlocale(LC_ALL, "Russian");
//
//	std::ifstream file;
//	file.exceptions(std::ifstream::badbit | std::ifstream::failbit);
//
//	try {
//		file.open("some1234.txt");
//		std::cout << "Success";
//
//		file.close();
//	}
//	catch (std::ifstream::failure& ex) {
//		std::cout << "Error";
//	}
//	catch (std::exception& ex) {
//		std::cout << ex.what();
//	}
//
//	return 0;
//}

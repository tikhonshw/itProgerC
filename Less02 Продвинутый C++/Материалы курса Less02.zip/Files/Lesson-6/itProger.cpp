﻿#include <iostream>
#include <clocale>
#include <string>

float divide(int a, int b) {
	if (b == 0)
		throw "Деление на ноль запрещено";

	if (a == 5)
		throw "Число 5 запрещено :)";

	return a / b;
}

int main() {
	setlocale(LC_ALL, "Russian");

	try {
		std::cout << divide(5, 10);
	}
	catch (const char* msg) { // const int msg
		std::cout << msg;
	}
	
	return 0;
}

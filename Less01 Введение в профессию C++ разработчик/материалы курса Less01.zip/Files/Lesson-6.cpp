﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	int x = 0;

	int nums[3];
	nums[x + 2] = 5;
	nums[1] = 10;
	nums[2] = 20;

	nums[1]++;
	nums[2] *= 3;

	nums[x] = 25;

	std::cout << nums[1] << std::endl;

	short numbers[10] = { 5, 6, 7, 9, 0, 7 };

	std::string names[] = { "Bob", "Alex", "John" };
	names[0] = "John";

	// Многомерные массивы
	short nums2[3][4] = {
		{4, 5, 5, 6},
		{7, 8},
		{5, 6}
	};
	nums2[1][0] += 2;
	std::cin >> nums2[1][0];
	std::cout << nums2[1][0];
	
	return 0;
}
﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	const short SIZE = 4, SIZE1 = 2, SIZE2 = 2;

	//short nums[SIZE];
	//short i = 0;
	//while (i < SIZE) {
	//	std::cout << "Enter number: ";
	//	std::cin >> nums[i];
	//	i++;
	//}

	//for (int i = 0; i < SIZE; i++) {
	//	// nums[i] += 5;
	//	std::cout << nums[i] << std::endl;
	//}

	int matrix[SIZE1][SIZE2] = {
		{4, 6},
		{7, 9}
	};

	int summa = 0;
	for (int i = 0; i < SIZE1; i++) {
		for (int j = 0; j < SIZE2; j++) {
			summa += matrix[i][j];
			std::cout << matrix[i][j] << std::endl;
		}
	}

	std::cout << summa;
	
	return 0;
}
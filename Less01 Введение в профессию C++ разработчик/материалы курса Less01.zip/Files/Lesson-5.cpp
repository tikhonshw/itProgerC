﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	int x, y;
	char math_operation;
	std::cin >> x >> y >> math_operation;

	switch (math_operation) {
	case '+': std::cout << x + y; break;
	case '-': std::cout << x - y; break;
	case '*': std::cout << x * y; break;
	case '/': 
		/*if (y == 0) std::cout << "Error";
		else std::cout << x / y; */

		y == 0 ? std::cout << "Error" : std::cout << x / y;
		break;
	default: std::cout << "Вы ввели неверный символ";
	}
	
	return 0;
}
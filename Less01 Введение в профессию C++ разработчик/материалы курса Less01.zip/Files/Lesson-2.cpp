﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	unsigned short num = 2;
	unsigned int number = 40;

	unsigned long long num3 = 6;

	std::cout << "Переменная: " << ULLONG_MAX << std::endl;
	number = 5;
	std::cout << "Переменная: " << UINT_MAX << std::endl;

	float num4 = 5.678F;
	double num5 = 6.0003F;

	char sym = '&';
	bool isHappy = false;
	std::string word = "Hello !!";

	short userNum1, userNum2, result;
	std::cout << "Enter number 1: ";
	std::cin >> userNum1;
	std::cout << "Enter number 2: ";
	std::cin >> userNum2;

	result = userNum1 + userNum2;
	std::cout << "Result: " << result << std::endl;

	auto num = 's';
	int num1{ 5 };
	const std::string key = "API_KEY";
	// key = "some";
	
	return 0;
}
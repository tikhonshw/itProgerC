﻿#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	int nums[] = { 5, 7 };
	for (int i = 0; i < 3; i++)
		std::cout << nums[i];
	
	return 0;
}
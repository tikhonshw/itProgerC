﻿#include <iostream>
#include <clocale>
#include <string>
#include <fstream>

int main() {
	setlocale(LC_ALL, "Russian");

	std::string file_name, user_text;

	std::cout << "Enter file name: ";
	getline(std::cin, file_name);

	std::cout << "Enter file text: ";
	getline(std::cin, user_text);

	std::ofstream file(file_name, std::ofstream::app);
	//file.open("some.txt");

	file << user_text << "\n";

	file.close();

	std::ifstream ifile(file_name);

	std::string file_text;
	while (getline(ifile, file_text)) {
		std::cout << file_text << std::endl;
	}

	ifile.close();

	system("pause");

	return 0;
}

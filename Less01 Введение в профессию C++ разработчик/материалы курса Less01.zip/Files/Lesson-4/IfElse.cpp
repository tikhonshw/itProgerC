#include <iostream>
#include <clocale>
#include <string>

int main() {
	setlocale(LC_ALL, "Russian");
	
	// �������� if-else
	short user_input;
	std::cin >> user_input;

	bool isHappy = false;
	/*if (!isHappy) {

	}*/

	if (user_input > 3 && isHappy) {
		std::cout << "You enter number bigger than 3";
		if (user_input == 5)
			std::cout << "You enter 5";
	}
	else if (user_input == 2)
	std::cout << "You enter 2";
	else if (user_input == 1)
	std::cout << "You enter 1";
	else
	std::cout << "Else";

	// ��������� ��������
	float x = 0.5f;
	int res;
	if (x == 0.5f)
	res = 1;
	else
	res = 0;

	int result = x == 0.5f && !isHappy ? 1 : 0;

	std::cout << res;

	return 0;
}